# memanggil file gempa dan import semua method/fungsi
from gempa import *

#membuat objek gempa dengan argumen
gempa1 = gempa('Banten', 1.2)

#informasi gempa
print('## info gempa maseh ##')
print()
gempa1.dampak()

# memanggil file gempa dan import semua method/fungsi
from gempa import *

#membuat objek gempa dengan argumen
gempa1 = gempa('palu', 6.1)

#informasi gempa
print('## info gempa maseh ##')
print()
gempa1.dampak()

# memanggil file gempa dan import semua method/fungsi
from gempa import *

#membuat objek gempa dengan argumen
gempa1 = gempa('cianjur', 5.6)

#informasi gempa
print('## info gempa maseh ##')
print()
gempa1.dampak()

# memanggil file gempa dan import semua method/fungsi
from gempa import *

#membuat objek gempa dengan argumen
gempa1 = gempa('jayapura', 3.3)

#informasi gempa
print('## info gempa maseh ##')
print()
gempa1.dampak()

# memanggil file gempa dan import semua method/fungsi
from gempa import *

#membuat objek gempa dengan argumen
gempa1 = gempa('garut', 4.0)

#informasi gempa
print('## info gempa maseh ##')
print()
gempa1.dampak()
